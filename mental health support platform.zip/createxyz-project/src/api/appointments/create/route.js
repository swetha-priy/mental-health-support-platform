async function handler({
  user_email,
  counselor_name,
  appointment_date,
  session_type,
  notes,
}) {
  if (!user_email || !counselor_name || !appointment_date || !session_type) {
    return {
      error:
        "user_email, counselor_name, appointment_date, and session_type are required",
    };
  }

  const result = await sql`
    INSERT INTO appointments (user_email, counselor_name, appointment_date, session_type, notes)
    VALUES (${user_email}, ${counselor_name}, ${appointment_date}, ${session_type}, ${
    notes || ""
  })
    RETURNING id, user_email, counselor_name, appointment_date, session_type, notes, status, created_at
  `;

  return result[0];
}
export async function POST(request) {
  return handler(await request.json());
}