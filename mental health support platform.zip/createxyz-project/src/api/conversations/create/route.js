async function handler({ user_email, counselor_id }) {
  if (!user_email || !counselor_id) {
    return {
      error: "user_email and counselor_id are required",
    };
  }

  const existingConversation = await sql`
    SELECT id, user_email, counselor_id, status, created_at, updated_at
    FROM conversations 
    WHERE user_email = ${user_email} AND counselor_id = ${counselor_id} AND status = 'active'
    ORDER BY created_at DESC
    LIMIT 1
  `;

  if (existingConversation.length > 0) {
    return {
      conversation: existingConversation[0],
      is_new: false,
    };
  }

  const newConversation = await sql`
    INSERT INTO conversations (user_email, counselor_id, status)
    VALUES (${user_email}, ${counselor_id}, 'active')
    RETURNING id, user_email, counselor_id, status, created_at, updated_at
  `;

  return {
    conversation: newConversation[0],
    is_new: true,
  };
}
export async function POST(request) {
  return handler(await request.json());
}