async function handler({ user_email }) {
  if (!user_email) {
    return {
      error: "user_email is required",
    };
  }

  const result = await sql`
    SELECT 
      c.id,
      c.user_email,
      c.counselor_id,
      c.status,
      c.created_at,
      c.updated_at,
      co.name as counselor_name,
      co.email as counselor_email,
      co.specialization,
      co.bio,
      co.credentials,
      co.languages,
      co.session_types,
      co.rating,
      co.is_online,
      co.is_peer_mentor,
      co.avatar_url,
      m.message_text as last_message,
      m.created_at as last_message_time,
      m.sender_type as last_message_sender,
      COALESCE(unread.unread_count, 0) as unread_count
    FROM conversations c
    LEFT JOIN counselors co ON c.counselor_id = co.id
    LEFT JOIN LATERAL (
      SELECT message_text, created_at, sender_type
      FROM messages 
      WHERE conversation_id = c.id 
      ORDER BY created_at DESC 
      LIMIT 1
    ) m ON true
    LEFT JOIN (
      SELECT 
        conversation_id,
        COUNT(*) as unread_count
      FROM messages 
      WHERE conversation_id IN (
        SELECT id FROM conversations WHERE user_email = ${user_email}
      )
      AND message_status = 'sent'
      AND sender_type = 'counselor'
      GROUP BY conversation_id
    ) unread ON unread.conversation_id = c.id
    WHERE c.user_email = ${user_email}
    ORDER BY 
      COALESCE(m.created_at, c.updated_at) DESC,
      c.created_at DESC
  `;

  return result;
}
export async function POST(request) {
  return handler(await request.json());
}