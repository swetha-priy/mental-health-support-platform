async function handler({ specialization, is_online, search, is_peer_mentor }) {
  let queryString = `
    SELECT 
      id, 
      name, 
      email, 
      specialization, 
      bio, 
      credentials, 
      languages, 
      session_types, 
      rating, 
      is_online, 
      is_peer_mentor, 
      avatar_url, 
      created_at, 
      updated_at
    FROM counselors 
    WHERE 1=1
  `;

  const values = [];
  let paramCount = 0;

  if (specialization) {
    paramCount++;
    queryString += ` AND LOWER(specialization) LIKE LOWER($${paramCount})`;
    values.push(`%${specialization}%`);
  }

  if (typeof is_online === "boolean") {
    paramCount++;
    queryString += ` AND is_online = $${paramCount}`;
    values.push(is_online);
  }

  if (typeof is_peer_mentor === "boolean") {
    paramCount++;
    queryString += ` AND is_peer_mentor = $${paramCount}`;
    values.push(is_peer_mentor);
  }

  if (search) {
    paramCount++;
    queryString += ` AND (
      LOWER(name) LIKE LOWER($${paramCount}) 
      OR LOWER(specialization) LIKE LOWER($${paramCount})
      OR LOWER(bio) LIKE LOWER($${paramCount})
    )`;
    values.push(`%${search}%`);
  }

  queryString += ` ORDER BY is_online DESC, rating DESC, name ASC`;

  const result = await sql(queryString, values);
  return result;
}
export async function POST(request) {
  return handler(await request.json());
}