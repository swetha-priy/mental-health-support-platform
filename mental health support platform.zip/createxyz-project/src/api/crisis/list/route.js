async function handler() {
  const result = await sql`
    SELECT id, name, phone, description, availability, priority_level
    FROM crisis_contacts 
    ORDER BY priority_level ASC, name ASC
  `;

  return result;
}
export async function POST(request) {
  return handler(await request.json());
}