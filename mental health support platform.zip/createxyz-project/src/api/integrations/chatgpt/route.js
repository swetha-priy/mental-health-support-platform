async function handler({ messages }) {
  if (!messages || !Array.isArray(messages)) {
    return { error: "messages array is required" };
  }

  if (messages.length === 0) {
    return { error: "messages array cannot be empty" };
  }

  const session = getSession();
  if (!session?.user?.email) {
    return { error: "User authentication required" };
  }

  try {
    const response = await fetch("/integrations/chat-gpt/conversationgpt4", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        messages: messages,
      }),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      console.error("ChatGPT API error:", response.status, errorData);

      if (response.status === 401) {
        return { error: "API authentication failed" };
      } else if (response.status === 429) {
        return { error: "Rate limit exceeded. Please try again in a moment." };
      } else if (response.status === 500) {
        return { error: "ChatGPT service temporarily unavailable" };
      } else {
        return { error: "Failed to get response from AI service" };
      }
    }

    const data = await response.json();

    if (!data.choices || data.choices.length === 0) {
      return { error: "No response generated" };
    }

    return {
      choices: data.choices,
      usage: data.usage,
      model: data.model,
      status: data.status,
    };
  } catch (error) {
    console.error("ChatGPT integration error:", error);
    return { error: "Internal server error while processing request" };
  }
}
export async function POST(request) {
  return handler(await request.json());
}