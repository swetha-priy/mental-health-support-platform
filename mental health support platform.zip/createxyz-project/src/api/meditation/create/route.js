async function handler({
  user_email,
  session_type,
  duration_minutes,
  planned_duration,
  meditation_title,
  notes,
  mood_before,
  mood_after,
}) {
  if (!user_email || !session_type || !duration_minutes) {
    return {
      error: "user_email, session_type, and duration_minutes are required",
    };
  }

  if (mood_before && (mood_before < 1 || mood_before > 10)) {
    return { error: "mood_before must be between 1 and 10" };
  }

  if (mood_after && (mood_after < 1 || mood_after > 10)) {
    return { error: "mood_after must be between 1 and 10" };
  }

  const result = await sql`
    INSERT INTO meditation_sessions (
      user_email, 
      session_type, 
      duration_minutes, 
      planned_duration, 
      meditation_title, 
      notes, 
      mood_before, 
      mood_after
    )
    VALUES (
      ${user_email}, 
      ${session_type}, 
      ${duration_minutes}, 
      ${planned_duration || null}, 
      ${meditation_title || null}, 
      ${notes || null}, 
      ${mood_before || null}, 
      ${mood_after || null}
    )
    RETURNING id, user_email, session_type, duration_minutes, planned_duration, meditation_title, completed_at, notes, mood_before, mood_after
  `;

  return result[0];
}
export async function POST(request) {
  return handler(await request.json());
}