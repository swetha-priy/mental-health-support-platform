async function handler({ user_email, limit }) {
  if (!user_email) {
    return { error: "user_email is required" };
  }

  const limitValue = limit && limit > 0 ? limit : 50;

  const sessions = await sql`
    SELECT id, user_email, session_type, duration_minutes, planned_duration, meditation_title, completed_at, notes, mood_before, mood_after
    FROM meditation_sessions 
    WHERE user_email = ${user_email}
    ORDER BY completed_at DESC
    LIMIT ${limitValue}
  `;

  const stats = await sql`
    SELECT 
      COUNT(*) as total_sessions,
      COALESCE(SUM(duration_minutes), 0) as total_minutes,
      COALESCE(AVG(duration_minutes), 0) as avg_duration
    FROM meditation_sessions 
    WHERE user_email = ${user_email}
  `;

  const recentSessions = await sql`
    SELECT DATE(completed_at) as session_date
    FROM meditation_sessions 
    WHERE user_email = ${user_email}
    ORDER BY completed_at DESC
    LIMIT 30
  `;

  let currentStreak = 0;
  if (recentSessions.length > 0) {
    const today = new Date();
    const sessionDates = recentSessions.map((s) => new Date(s.session_date));

    let checkDate = new Date(today);
    checkDate.setHours(0, 0, 0, 0);

    for (let i = 0; i < sessionDates.length; i++) {
      const sessionDate = new Date(sessionDates[i]);
      sessionDate.setHours(0, 0, 0, 0);

      if (sessionDate.getTime() === checkDate.getTime()) {
        currentStreak++;
        checkDate.setDate(checkDate.getDate() - 1);
      } else if (sessionDate.getTime() < checkDate.getTime()) {
        break;
      }
    }
  }

  return {
    sessions,
    stats: {
      total_sessions: parseInt(stats[0].total_sessions),
      total_minutes: parseInt(stats[0].total_minutes),
      avg_duration: Math.round(parseFloat(stats[0].avg_duration)),
      current_streak: currentStreak,
    },
  };
}
export async function POST(request) {
  return handler(await request.json());
}