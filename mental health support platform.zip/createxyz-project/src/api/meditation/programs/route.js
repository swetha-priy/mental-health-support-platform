async function handler({ category }) {
  let result;

  if (category) {
    result = await sql`
      SELECT id, title, description, category, duration_minutes, session_type, instructions, audio_url, background_sound, created_at
      FROM meditation_programs 
      WHERE category = ${category}
      ORDER BY title ASC
    `;
  } else {
    result = await sql`
      SELECT id, title, description, category, duration_minutes, session_type, instructions, audio_url, background_sound, created_at
      FROM meditation_programs 
      ORDER BY category ASC, title ASC
    `;
  }

  return result;
}
export async function POST(request) {
  return handler(await request.json());
}