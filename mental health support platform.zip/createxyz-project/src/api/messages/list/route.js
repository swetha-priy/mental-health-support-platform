async function handler({ conversation_id, limit }) {
  if (!conversation_id) {
    return {
      error: "conversation_id is required",
    };
  }

  const limitValue = limit && limit > 0 ? limit : 100;

  let query = `
    SELECT 
      id, 
      conversation_id, 
      sender_type, 
      sender_email, 
      message_text, 
      file_url, 
      file_name, 
      file_type, 
      message_status, 
      created_at
    FROM messages 
    WHERE conversation_id = $1 
    ORDER BY created_at ASC 
    LIMIT $2
  `;

  const messages = await sql(query, [conversation_id, limitValue]);

  if (messages.length > 0) {
    const messageIds = messages.map((msg) => msg.id);
    const placeholders = messageIds
      .map((_, index) => `$${index + 1}`)
      .join(",");

    await sql(
      `
      UPDATE messages 
      SET message_status = 'read' 
      WHERE id IN (${placeholders}) AND message_status != 'read'
    `,
      messageIds
    );
  }

  return {
    messages: messages,
    total_count: messages.length,
    conversation_id: conversation_id,
  };
}
export async function POST(request) {
  return handler(await request.json());
}