async function handler({
  conversation_id,
  sender_type,
  sender_email,
  message_text,
  file_url,
  file_name,
  file_type,
}) {
  if (!conversation_id || !sender_type || !sender_email) {
    return {
      error: "conversation_id, sender_type, and sender_email are required",
    };
  }

  if (!message_text && !file_url) {
    return {
      error: "Either message_text or file_url must be provided",
    };
  }

  if (sender_type !== "user" && sender_type !== "counselor") {
    return {
      error: "sender_type must be either 'user' or 'counselor'",
    };
  }

  const [newMessage, updatedConversation] = await sql.transaction([
    sql`
      INSERT INTO messages (conversation_id, sender_type, sender_email, message_text, file_url, file_name, file_type)
      VALUES (${conversation_id}, ${sender_type}, ${sender_email}, ${
      message_text || null
    }, ${file_url || null}, ${file_name || null}, ${file_type || null})
      RETURNING id, conversation_id, sender_type, sender_email, message_text, file_url, file_name, file_type, message_status, created_at
    `,
    sql`
      UPDATE conversations 
      SET updated_at = CURRENT_TIMESTAMP 
      WHERE id = ${conversation_id}
      RETURNING id, updated_at
    `,
  ]);

  return newMessage[0];
}
export async function POST(request) {
  return handler(await request.json());
}