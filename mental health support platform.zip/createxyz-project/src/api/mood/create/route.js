async function handler({ mood_score, emotions, notes, user_email }) {
  if (!mood_score || !user_email) {
    return { error: "mood_score and user_email are required" };
  }

  if (mood_score < 1 || mood_score > 10) {
    return { error: "mood_score must be between 1 and 10" };
  }

  const result = await sql`
    INSERT INTO mood_entries (user_email, mood_score, emotions, notes)
    VALUES (${user_email}, ${mood_score}, ${emotions || []}, ${notes || ""})
    RETURNING id, user_email, mood_score, emotions, notes, created_at
  `;

  return result[0];
}
export async function POST(request) {
  return handler(await request.json());
}