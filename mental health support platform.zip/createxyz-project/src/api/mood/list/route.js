async function handler({ user_email, limit }) {
  if (!user_email) {
    return { error: "user_email is required" };
  }

  const limitValue = limit && limit > 0 ? limit : 50;

  const result = await sql`
    SELECT id, user_email, mood_score, emotions, notes, created_at
    FROM mood_entries 
    WHERE user_email = ${user_email}
    ORDER BY created_at DESC
    LIMIT ${limitValue}
  `;

  return result;
}
export async function POST(request) {
  return handler(await request.json());
}