async function handler({ category }) {
  let result;

  if (category) {
    result = await sql`
      SELECT id, title, category, content, resource_type, external_url, created_at 
      FROM resources 
      WHERE category = ${category}
      ORDER BY created_at DESC
    `;
  } else {
    result = await sql`
      SELECT id, title, category, content, resource_type, external_url, created_at 
      FROM resources 
      ORDER BY created_at DESC
    `;
  }

  return result;
}
export async function POST(request) {
  return handler(await request.json());
}