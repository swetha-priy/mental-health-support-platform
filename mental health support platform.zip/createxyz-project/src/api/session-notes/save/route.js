async function handler({ conversation_id, user_email, notes }) {
  if (!conversation_id || !user_email || !notes) {
    return {
      error: "conversation_id, user_email, and notes are required",
    };
  }

  const existingNotes = await sql`
    SELECT id, conversation_id, user_email, notes, created_at
    FROM session_notes 
    WHERE conversation_id = ${conversation_id} AND user_email = ${user_email}
    LIMIT 1
  `;

  if (existingNotes.length > 0) {
    const updatedNotes = await sql`
      UPDATE session_notes 
      SET notes = ${notes}, created_at = CURRENT_TIMESTAMP
      WHERE conversation_id = ${conversation_id} AND user_email = ${user_email}
      RETURNING id, conversation_id, user_email, notes, created_at
    `;
    return updatedNotes[0];
  } else {
    const newNotes = await sql`
      INSERT INTO session_notes (conversation_id, user_email, notes)
      VALUES (${conversation_id}, ${user_email}, ${notes})
      RETURNING id, conversation_id, user_email, notes, created_at
    `;
    return newNotes[0];
  }
}
export async function POST(request) {
  return handler(await request.json());
}