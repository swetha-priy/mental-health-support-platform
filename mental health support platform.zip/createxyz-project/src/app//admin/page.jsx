"use client";
import React from "react";

function MainComponent() {
  const [currentSection, setCurrentSection] = React.useState("overview");
  const { data: user, loading: userLoading } = useUser();
  const { signOut } = useAuth();
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState("");

  const [users, setUsers] = React.useState([]);
  const [resources, setResources] = React.useState([]);
  const [meditationPrograms, setMeditationPrograms] = React.useState([]);
  const [crisisContacts, setCrisisContacts] = React.useState([]);
  const [appointments, setAppointments] = React.useState([]);
  const [moodEntries, setMoodEntries] = React.useState([]);
  const [meditationSessions, setMeditationSessions] = React.useState([]);

  const [searchTerm, setSearchTerm] = React.useState("");
  const [filterCategory, setFilterCategory] = React.useState("");
  const [dateRange, setDateRange] = React.useState("30");

  const [showAddForm, setShowAddForm] = React.useState(false);
  const [editingItem, setEditingItem] = React.useState(null);
  const [formData, setFormData] = React.useState({});

  const [stats, setStats] = React.useState({
    totalUsers: 0,
    totalResources: 0,
    totalAppointments: 0,
    totalMoodEntries: 0,
    totalMeditationSessions: 0,
    avgMoodScore: 0,
    totalMeditationMinutes: 0,
    activeUsers: 0,
  });

  React.useEffect(() => {
    if (user && isAdmin()) {
      loadDashboardData();
    }
  }, [user]);

  const isAdmin = () => {
    return user?.email === "admin@mindwell.com" || user?.role === "admin";
  };

  const loadDashboardData = async () => {
    setLoading(true);
    try {
      const [resourcesRes, programsRes, crisisRes, moodRes, meditationRes] =
        await Promise.all([
          fetch("/api/resources/list", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({}),
          }),
          fetch("/api/meditation/programs", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({}),
          }),
          fetch("/api/crisis/list", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
          }),
          fetch("/api/mood/list", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ user_email: "all", limit: 100 }),
          }),
          fetch("/api/meditation/list", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ user_email: "all", limit: 100 }),
          }),
        ]);

      if (resourcesRes.ok) {
        const resourcesData = await resourcesRes.json();
        setResources(Array.isArray(resourcesData) ? resourcesData : []);
      }

      if (programsRes.ok) {
        const programsData = await programsRes.json();
        setMeditationPrograms(Array.isArray(programsData) ? programsData : []);
      }

      if (crisisRes.ok) {
        const crisisData = await crisisRes.json();
        setCrisisContacts(Array.isArray(crisisData) ? crisisData : []);
      }

      if (moodRes.ok) {
        const moodData = await moodRes.json();
        setMoodEntries(Array.isArray(moodData) ? moodData : []);
      }

      if (meditationRes.ok) {
        const meditationData = await meditationRes.json();
        setMeditationSessions(
          Array.isArray(meditationData.sessions) ? meditationData.sessions : []
        );
      }

      calculateStats();
    } catch (err) {
      console.error("Error loading dashboard data:", err);
      setError("Failed to load dashboard data");
    }
    setLoading(false);
  };

  const calculateStats = () => {
    const uniqueUsers = new Set();
    moodEntries.forEach((entry) => uniqueUsers.add(entry.user_email));
    meditationSessions.forEach((session) =>
      uniqueUsers.add(session.user_email)
    );

    const totalMoodScore = moodEntries.reduce(
      (sum, entry) => sum + entry.mood_score,
      0
    );
    const avgMoodScore =
      moodEntries.length > 0 ? totalMoodScore / moodEntries.length : 0;

    const totalMeditationMinutes = meditationSessions.reduce(
      (sum, session) => sum + session.duration_minutes,
      0
    );

    setStats({
      totalUsers: uniqueUsers.size,
      totalResources: resources.length,
      totalAppointments: appointments.length,
      totalMoodEntries: moodEntries.length,
      totalMeditationSessions: meditationSessions.length,
      avgMoodScore: avgMoodScore.toFixed(1),
      totalMeditationMinutes,
      activeUsers: uniqueUsers.size,
    });
  };

  const handleSignOut = async () => {
    await signOut({
      callbackUrl: "/",
      redirect: true,
    });
  };

  const filteredData = (data, searchFields) => {
    return data.filter((item) => {
      const matchesSearch = searchFields.some((field) =>
        item[field]?.toLowerCase().includes(searchTerm.toLowerCase())
      );
      const matchesCategory =
        !filterCategory || item.category === filterCategory;
      return matchesSearch && matchesCategory;
    });
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString();
  };

  const formatDateTime = (dateString) => {
    return new Date(dateString).toLocaleString();
  };

  if (userLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <i className="fas fa-cog fa-spin text-4xl text-blue-500 mb-4"></i>
          <p className="text-gray-600">Loading admin dashboard...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-white rounded-2xl p-8 shadow-xl text-center">
          <i className="fas fa-shield-alt text-4xl text-red-500 mb-4"></i>
          <h1 className="text-2xl font-bold text-gray-800 mb-4">
            Admin Access Required
          </h1>
          <p className="text-gray-600 mb-6">
            Please sign in with admin credentials to access the dashboard.
          </p>
          <a
            href="/account/signin"
            className="block w-full bg-blue-500 text-white py-3 px-4 rounded-lg hover:bg-blue-600 transition-colors"
          >
            Sign In
          </a>
        </div>
      </div>
    );
  }

  if (!isAdmin()) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-50 to-orange-50 flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-white rounded-2xl p-8 shadow-xl text-center">
          <i className="fas fa-exclamation-triangle text-4xl text-red-500 mb-4"></i>
          <h1 className="text-2xl font-bold text-gray-800 mb-4">
            Access Denied
          </h1>
          <p className="text-gray-600 mb-6">
            You don't have permission to access the admin dashboard.
          </p>
          <a
            href="/"
            className="block w-full bg-blue-500 text-white py-3 px-4 rounded-lg hover:bg-blue-600 transition-colors"
          >
            Back to Dashboard
          </a>
        </div>
      </div>
    );
  }

  const renderOverview = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <i className="fas fa-users text-blue-600 text-xl"></i>
            </div>
            <div className="ml-4">
              <p className="text-sm text-gray-600">Total Users</p>
              <p className="text-2xl font-bold text-gray-900">
                {stats.totalUsers}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <i className="fas fa-book text-green-600 text-xl"></i>
            </div>
            <div className="ml-4">
              <p className="text-sm text-gray-600">Resources</p>
              <p className="text-2xl font-bold text-gray-900">
                {stats.totalResources}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
              <i className="fas fa-smile text-purple-600 text-xl"></i>
            </div>
            <div className="ml-4">
              <p className="text-sm text-gray-600">Avg Mood Score</p>
              <p className="text-2xl font-bold text-gray-900">
                {stats.avgMoodScore}/10
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center">
            <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center">
              <i className="fas fa-meditation text-indigo-600 text-xl"></i>
            </div>
            <div className="ml-4">
              <p className="text-sm text-gray-600">Meditation Minutes</p>
              <p className="text-2xl font-bold text-gray-900">
                {stats.totalMeditationMinutes}
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">
            Recent Activity
          </h3>
          <div className="space-y-3">
            {moodEntries.slice(0, 5).map((entry) => (
              <div
                key={entry.id}
                className="flex justify-between items-center py-2 border-b border-gray-100"
              >
                <div>
                  <p className="text-sm font-medium text-gray-800">
                    Mood Entry
                  </p>
                  <p className="text-xs text-gray-600">{entry.user_email}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-bold text-blue-600">
                    {entry.mood_score}/10
                  </p>
                  <p className="text-xs text-gray-500">
                    {formatDate(entry.created_at)}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">
            System Health
          </h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Database Status</span>
              <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded">
                Online
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">API Status</span>
              <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded">
                Healthy
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Crisis Contacts</span>
              <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded">
                {crisisContacts.length} Active
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Meditation Programs</span>
              <span className="px-2 py-1 bg-purple-100 text-purple-800 text-xs rounded">
                {meditationPrograms.length} Available
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderUserManagement = () => {
    const uniqueUsers = Array.from(
      new Set([
        ...moodEntries.map((e) => e.user_email),
        ...meditationSessions.map((s) => s.user_email),
      ])
    ).map((email) => {
      const userMoodEntries = moodEntries.filter((e) => e.user_email === email);
      const userMeditationSessions = meditationSessions.filter(
        (s) => s.user_email === email
      );
      const lastActivity = Math.max(
        ...userMoodEntries.map((e) => new Date(e.created_at).getTime()),
        ...userMeditationSessions.map((s) => new Date(s.completed_at).getTime())
      );

      return {
        email,
        moodEntries: userMoodEntries.length,
        meditationSessions: userMeditationSessions.length,
        lastActivity: new Date(lastActivity),
        avgMood:
          userMoodEntries.length > 0
            ? (
                userMoodEntries.reduce((sum, e) => sum + e.mood_score, 0) /
                userMoodEntries.length
              ).toFixed(1)
            : "N/A",
      };
    });

    const filteredUsers = uniqueUsers.filter((user) =>
      user.email.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <h2 className="text-2xl font-bold text-gray-800">User Management</h2>
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="Search users..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    User Email
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Mood Entries
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Meditation Sessions
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Avg Mood
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Last Activity
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredUsers.map((user) => (
                  <tr key={user.email} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">
                        {user.email}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">
                        {user.moodEntries}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">
                        {user.meditationSessions}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">
                        {user.avgMood}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">
                        {formatDateTime(user.lastActivity)}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  };

  const renderContentManagement = () => {
    const filteredResources = filteredData(resources, [
      "title",
      "category",
      "content",
    ]);

    return (
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <h2 className="text-2xl font-bold text-gray-800">
            Content Management
          </h2>
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="Search content..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
            <select
              value={filterCategory}
              onChange={(e) => setFilterCategory(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">All Categories</option>
              <option value="anxiety">Anxiety</option>
              <option value="depression">Depression</option>
              <option value="stress">Stress</option>
              <option value="mindfulness">Mindfulness</option>
              <option value="self-care">Self Care</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white rounded-lg shadow">
            <div className="px-6 py-4 border-b border-gray-200">
              <h3 className="text-lg font-semibold text-gray-800">Resources</h3>
            </div>
            <div className="p-6">
              <div className="space-y-4 max-h-96 overflow-y-auto">
                {filteredResources.map((resource) => (
                  <div
                    key={resource.id}
                    className="border border-gray-200 rounded-lg p-4"
                  >
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="font-semibold text-gray-800">
                        {resource.title}
                      </h4>
                      <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded">
                        {resource.category}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600 mb-2 line-clamp-2">
                      {resource.content}
                    </p>
                    <div className="flex justify-between items-center text-xs text-gray-500">
                      <span>{resource.resource_type}</span>
                      <span>{formatDate(resource.created_at)}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow">
            <div className="px-6 py-4 border-b border-gray-200">
              <h3 className="text-lg font-semibold text-gray-800">
                Meditation Programs
              </h3>
            </div>
            <div className="p-6">
              <div className="space-y-4 max-h-96 overflow-y-auto">
                {meditationPrograms.map((program) => (
                  <div
                    key={program.id}
                    className="border border-gray-200 rounded-lg p-4"
                  >
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="font-semibold text-gray-800">
                        {program.title}
                      </h4>
                      <span className="px-2 py-1 bg-indigo-100 text-indigo-800 text-xs rounded">
                        {program.duration_minutes} min
                      </span>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">
                      {program.description}
                    </p>
                    <div className="flex justify-between items-center text-xs text-gray-500">
                      <span>{program.category}</span>
                      <span>{program.session_type}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow">
          <div className="px-6 py-4 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-800">
              Crisis Contacts
            </h3>
          </div>
          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {crisisContacts.map((contact) => (
                <div
                  key={contact.id}
                  className="border border-gray-200 rounded-lg p-4"
                >
                  <div className="flex justify-between items-start mb-2">
                    <h4 className="font-semibold text-gray-800">
                      {contact.name}
                    </h4>
                    <span
                      className={`px-2 py-1 text-xs rounded ${
                        contact.priority_level === 1
                          ? "bg-red-100 text-red-800"
                          : "bg-yellow-100 text-yellow-800"
                      }`}
                    >
                      Priority {contact.priority_level}
                    </span>
                  </div>
                  <p className="text-lg font-bold text-blue-600 mb-2">
                    {contact.phone}
                  </p>
                  <p className="text-sm text-gray-600 mb-2">
                    {contact.description}
                  </p>
                  <p className="text-xs text-gray-500">
                    {contact.availability}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderAnalytics = () => {
    const moodTrends = moodEntries.slice(0, 30).reverse();
    const meditationTrends = meditationSessions.slice(0, 30).reverse();

    return (
      <div className="space-y-6">
        <h2 className="text-2xl font-bold text-gray-800">
          Analytics & Insights
        </h2>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">
              Mood Trends (Last 30 Entries)
            </h3>
            <div className="space-y-2">
              {moodTrends.map((entry, index) => (
                <div
                  key={entry.id}
                  className="flex items-center justify-between py-1"
                >
                  <span className="text-sm text-gray-600">
                    {formatDate(entry.created_at)}
                  </span>
                  <div className="flex items-center">
                    <div className="w-32 bg-gray-200 rounded-full h-2 mr-2">
                      <div
                        className="bg-blue-500 h-2 rounded-full"
                        style={{ width: `${(entry.mood_score / 10) * 100}%` }}
                      ></div>
                    </div>
                    <span className="text-sm font-medium text-gray-800 w-8">
                      {entry.mood_score}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">
              Meditation Usage
            </h3>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Total Sessions</span>
                <span className="text-lg font-bold text-indigo-600">
                  {meditationSessions.length}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Total Minutes</span>
                <span className="text-lg font-bold text-indigo-600">
                  {stats.totalMeditationMinutes}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Average Session</span>
                <span className="text-lg font-bold text-indigo-600">
                  {meditationSessions.length > 0
                    ? Math.round(
                        stats.totalMeditationMinutes / meditationSessions.length
                      )
                    : 0}{" "}
                  min
                </span>
              </div>
            </div>

            <div className="mt-6">
              <h4 className="text-md font-semibold text-gray-700 mb-3">
                Recent Sessions
              </h4>
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {meditationTrends.map((session) => (
                  <div
                    key={session.id}
                    className="flex justify-between items-center py-1 text-sm"
                  >
                    <span className="text-gray-600">
                      {session.meditation_title || session.session_type}
                    </span>
                    <span className="font-medium text-gray-800">
                      {session.duration_minutes} min
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">
            User Engagement Metrics
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600 mb-2">
                {stats.activeUsers}
              </div>
              <div className="text-sm text-gray-600">Active Users</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-green-600 mb-2">
                {moodEntries.length > 0
                  ? Math.round((moodEntries.length / stats.activeUsers) * 10) /
                    10
                  : 0}
              </div>
              <div className="text-sm text-gray-600">
                Avg Mood Entries per User
              </div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-600 mb-2">
                {meditationSessions.length > 0
                  ? Math.round(
                      (meditationSessions.length / stats.activeUsers) * 10
                    ) / 10
                  : 0}
              </div>
              <div className="text-sm text-gray-600">Avg Sessions per User</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-orange-600 mb-2">
                {stats.activeUsers > 0
                  ? Math.round(
                      (stats.totalMeditationMinutes / stats.activeUsers) * 10
                    ) / 10
                  : 0}
              </div>
              <div className="text-sm text-gray-600">Avg Minutes per User</div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderSystemSettings = () => (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-800">System Settings</h2>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">
            Platform Configuration
          </h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">User Registration</span>
              <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded">
                Enabled
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Crisis Support</span>
              <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded">
                Active
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">AI Chatbot</span>
              <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded">
                Online
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Meditation Programs</span>
              <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded">
                {meditationPrograms.length} Available
              </span>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">
            Data Management
          </h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Total Mood Entries</span>
              <span className="text-sm font-medium text-gray-800">
                {moodEntries.length}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">
                Total Meditation Sessions
              </span>
              <span className="text-sm font-medium text-gray-800">
                {meditationSessions.length}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Total Resources</span>
              <span className="text-sm font-medium text-gray-800">
                {resources.length}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Crisis Contacts</span>
              <span className="text-sm font-medium text-gray-800">
                {crisisContacts.length}
              </span>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">
          Admin Actions
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <button
            onClick={loadDashboardData}
            disabled={loading}
            className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 disabled:bg-gray-300 transition-colors"
          >
            {loading ? "Refreshing..." : "Refresh Data"}
          </button>
          <button className="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 transition-colors">
            Export Analytics
          </button>
          <button className="bg-purple-500 text-white px-4 py-2 rounded-lg hover:bg-purple-600 transition-colors">
            System Backup
          </button>
        </div>
      </div>

      <div className="bg-yellow-50 border border-yellow-200 p-6 rounded-lg">
        <h3 className="text-lg font-semibold text-yellow-800 mb-2">
          <i className="fas fa-exclamation-triangle mr-2"></i>
          Important Notice
        </h3>
        <p className="text-yellow-700">
          This admin dashboard provides access to sensitive user data and system
          controls. Please ensure all actions comply with privacy regulations
          and platform policies.
        </p>
      </div>
    </div>
  );

  const navigationItems = [
    { id: "overview", label: "Overview", icon: "fas fa-tachometer-alt" },
    { id: "users", label: "User Management", icon: "fas fa-users" },
    { id: "content", label: "Content Management", icon: "fas fa-edit" },
    { id: "analytics", label: "Analytics", icon: "fas fa-chart-bar" },
    { id: "settings", label: "System Settings", icon: "fas fa-cog" },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <i className="fas fa-shield-alt text-2xl text-blue-500 mr-3"></i>
              <h1 className="text-xl font-bold text-gray-900">
                Admin Dashboard
              </h1>
            </div>
            <div className="flex items-center space-x-4">
              <a
                href="/"
                className="text-sm text-gray-600 hover:text-gray-900 flex items-center"
              >
                <i className="fas fa-arrow-left mr-1"></i>
                Back to App
              </a>
              <span className="text-sm text-gray-600">
                {user.name || user.email}
              </span>
              <button
                onClick={handleSignOut}
                className="text-sm text-gray-500 hover:text-gray-700 flex items-center"
              >
                <i className="fas fa-sign-out-alt mr-1"></i>
                Sign Out
              </button>
            </div>
          </div>
        </div>
      </header>

      <nav className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex space-x-8 overflow-x-auto">
            {navigationItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setCurrentSection(item.id)}
                className={`flex items-center px-3 py-4 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
                  currentSection === item.id
                    ? "border-blue-500 text-blue-600"
                    : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                }`}
              >
                <i className={`${item.icon} mr-2`}></i>
                {item.label}
              </button>
            ))}
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-4">
            {error}
            <button
              onClick={() => setError("")}
              className="float-right text-red-500 hover:text-red-700"
            >
              ×
            </button>
          </div>
        )}

        {currentSection === "overview" && renderOverview()}
        {currentSection === "users" && renderUserManagement()}
        {currentSection === "content" && renderContentManagement()}
        {currentSection === "analytics" && renderAnalytics()}
        {currentSection === "settings" && renderSystemSettings()}
      </main>
    </div>
  );
}

export default MainComponent;