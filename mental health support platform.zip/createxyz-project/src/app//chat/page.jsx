"use client";
import React from "react";

import { useUpload } from "../utilities/runtime-helpers";

function MainComponent() {
  const [currentView, setCurrentView] = React.useState("conversations");
  const [selectedConversation, setSelectedConversation] = React.useState(null);
  const [conversations, setConversations] = React.useState([]);
  const [counselors, setCounselors] = React.useState([]);
  const [messages, setMessages] = React.useState([]);
  const [newMessage, setNewMessage] = React.useState("");
  const [isTyping, setIsTyping] = React.useState(false);
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState("");
  const [searchTerm, setSearchTerm] = React.useState("");
  const [filterSpecialization, setFilterSpecialization] = React.useState("");
  const [showEmergencyModal, setShowEmergencyModal] = React.useState(false);
  const [sessionNotes, setSessionNotes] = React.useState("");
  const [showNotesModal, setShowNotesModal] = React.useState(false);
  const [uploadingFile, setUploadingFile] = React.useState(false);

  const { data: user, loading: userLoading } = useUser();
  const [upload] = useUpload();
  const messagesEndRef = React.useRef(null);
  const fileInputRef = React.useRef(null);

  // Mock data for counselors (in real app, this would come from API)
  const mockCounselors = [
    {
      id: 1,
      name: "Dr. Sarah Johnson",
      specialization: "Anxiety & Depression",
      avatar: "/images/counselor1.jpg",
      rating: 4.9,
      isOnline: true,
      bio: "Licensed therapist with 10+ years experience in cognitive behavioral therapy and mindfulness-based interventions.",
      credentials:
        "PhD in Clinical Psychology, Licensed Clinical Social Worker",
      languages: ["English", "Spanish"],
      sessionTypes: ["Individual Therapy", "Group Sessions", "Crisis Support"],
    },
    {
      id: 2,
      name: "Michael Chen",
      specialization: "Stress Management",
      avatar: "/images/counselor2.jpg",
      rating: 4.8,
      isOnline: false,
      lastSeen: "2 hours ago",
      bio: "Specializing in workplace stress, burnout prevention, and work-life balance strategies.",
      credentials:
        "MA in Counseling Psychology, Certified Stress Management Specialist",
      languages: ["English", "Mandarin"],
      sessionTypes: ["Individual Therapy", "Workshops"],
    },
    {
      id: 3,
      name: "Emma Rodriguez",
      specialization: "Trauma & PTSD",
      avatar: "/images/counselor3.jpg",
      rating: 4.9,
      isOnline: true,
      bio: "Trauma-informed therapist using EMDR and somatic approaches to healing.",
      credentials: "LMFT, EMDR Certified, Trauma Specialist",
      languages: ["English", "Spanish"],
      sessionTypes: ["Individual Therapy", "EMDR Sessions", "Crisis Support"],
    },
    {
      id: 4,
      name: "Alex Thompson",
      specialization: "Peer Support",
      avatar: "/images/mentor1.jpg",
      rating: 4.7,
      isOnline: true,
      isPeerMentor: true,
      bio: "Peer mentor with lived experience in recovery and mental health advocacy.",
      credentials: "Certified Peer Support Specialist, Mental Health First Aid",
      languages: ["English"],
      sessionTypes: ["Peer Support", "Group Sessions"],
    },
  ];

  // Mock conversations
  const mockConversations = [
    {
      id: 1,
      counselorId: 1,
      counselorName: "Dr. Sarah Johnson",
      lastMessage: "How are you feeling about the techniques we discussed?",
      lastMessageTime: new Date(Date.now() - 1000 * 60 * 30),
      unreadCount: 2,
      status: "active",
    },
    {
      id: 2,
      counselorId: 4,
      counselorName: "Alex Thompson",
      lastMessage: "Thanks for sharing that with me. You're doing great!",
      lastMessageTime: new Date(Date.now() - 1000 * 60 * 60 * 2),
      unreadCount: 0,
      status: "active",
    },
  ];

  React.useEffect(() => {
    if (user) {
      setCounselors(mockCounselors);
      setConversations(mockConversations);
    }
  }, [user]);

  React.useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  if (userLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <i className="fas fa-comments text-4xl text-blue-500 mb-4"></i>
          <p className="text-gray-600">Loading chat system...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-white rounded-2xl p-8 shadow-xl text-center">
          <i className="fas fa-comments text-4xl text-blue-500 mb-4"></i>
          <h1 className="text-2xl font-bold text-gray-800 mb-4">
            Chat with Counselors
          </h1>
          <p className="text-gray-600 mb-6">
            Connect with licensed counselors and peer mentors for support.
            Please sign in to access the chat system.
          </p>
          <div className="space-y-3">
            <a
              href="/account/signin"
              className="block w-full bg-blue-500 text-white py-3 px-4 rounded-lg hover:bg-blue-600 transition-colors"
            >
              Sign In
            </a>
            <a
              href="/account/signup"
              className="block w-full bg-gray-100 text-gray-700 py-3 px-4 rounded-lg hover:bg-gray-200 transition-colors"
            >
              Create Account
            </a>
          </div>
        </div>
      </div>
    );
  }

  const filteredCounselors = counselors.filter((counselor) => {
    const matchesSearch =
      counselor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      counselor.specialization.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSpecialization =
      !filterSpecialization ||
      counselor.specialization === filterSpecialization;
    return matchesSearch && matchesSpecialization;
  });

  const specializations = [...new Set(counselors.map((c) => c.specialization))];

  const startConversation = (counselor) => {
    const existingConversation = conversations.find(
      (c) => c.counselorId === counselor.id
    );
    if (existingConversation) {
      setSelectedConversation(existingConversation);
      loadMessages(existingConversation.id);
    } else {
      const newConversation = {
        id: Date.now(),
        counselorId: counselor.id,
        counselorName: counselor.name,
        lastMessage: "",
        lastMessageTime: new Date(),
        unreadCount: 0,
        status: "active",
      };
      setConversations((prev) => [newConversation, ...prev]);
      setSelectedConversation(newConversation);
      setMessages([]);
    }
    setCurrentView("chat");
  };

  const loadMessages = (conversationId) => {
    // Mock messages - in real app, fetch from API
    const mockMessages = [
      {
        id: 1,
        text: "Hello! I'm glad you reached out today. How are you feeling?",
        sender: "counselor",
        timestamp: new Date(Date.now() - 1000 * 60 * 60),
        status: "read",
      },
      {
        id: 2,
        text: "Hi Dr. Johnson. I've been feeling quite anxious lately, especially about work.",
        sender: "user",
        timestamp: new Date(Date.now() - 1000 * 60 * 50),
        status: "read",
      },
      {
        id: 3,
        text: "I understand. Work-related anxiety is very common. Can you tell me more about what specifically is causing you stress?",
        sender: "counselor",
        timestamp: new Date(Date.now() - 1000 * 60 * 45),
        status: "read",
      },
      {
        id: 4,
        text: "It's mainly the deadlines and feeling like I'm not meeting expectations. I keep worrying about making mistakes.",
        sender: "user",
        timestamp: new Date(Date.now() - 1000 * 60 * 40),
        status: "read",
      },
    ];
    setMessages(mockMessages);
  };

  const sendMessage = async () => {
    if (!newMessage.trim() || !selectedConversation) return;

    const message = {
      id: Date.now(),
      text: newMessage.trim(),
      sender: "user",
      timestamp: new Date(),
      status: "sent",
    };

    setMessages((prev) => [...prev, message]);
    setNewMessage("");

    // Update conversation last message
    setConversations((prev) =>
      prev.map((conv) =>
        conv.id === selectedConversation.id
          ? {
              ...conv,
              lastMessage: message.text,
              lastMessageTime: message.timestamp,
            }
          : conv
      )
    );

    // Simulate message delivery
    setTimeout(() => {
      setMessages((prev) =>
        prev.map((msg) =>
          msg.id === message.id ? { ...msg, status: "delivered" } : msg
        )
      );
    }, 1000);

    // Simulate counselor response
    setTimeout(() => {
      const response = {
        id: Date.now() + 1,
        text: "Thank you for sharing that with me. Those feelings are completely valid. Let's work through some strategies together.",
        sender: "counselor",
        timestamp: new Date(),
        status: "read",
      };
      setMessages((prev) => [...prev, response]);
    }, 3000);
  };

  const handleFileUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    setUploadingFile(true);
    try {
      const { url, error } = await upload({ file });
      if (error) {
        setError("Failed to upload file");
        return;
      }

      const fileMessage = {
        id: Date.now(),
        text: `Shared file: ${file.name}`,
        sender: "user",
        timestamp: new Date(),
        status: "sent",
        fileUrl: url,
        fileName: file.name,
        fileType: file.type,
      };

      setMessages((prev) => [...prev, fileMessage]);
    } catch (err) {
      console.error("File upload error:", err);
      setError("Failed to upload file");
    } finally {
      setUploadingFile(false);
    }
  };

  const formatTime = (timestamp) => {
    return new Date(timestamp).toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const formatDate = (timestamp) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffTime = Math.abs(now - date);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays === 1) return "Today";
    if (diffDays === 2) return "Yesterday";
    if (diffDays <= 7) return `${diffDays - 1} days ago`;
    return date.toLocaleDateString();
  };

  const renderCounselorCard = (counselor) => (
    <div
      key={counselor.id}
      className="bg-white p-6 rounded-lg shadow hover:shadow-lg transition-shadow"
    >
      <div className="flex items-start space-x-4">
        <div className="relative">
          <div className="w-16 h-16 bg-gray-300 rounded-full flex items-center justify-center">
            <i className="fas fa-user text-gray-600 text-xl"></i>
          </div>
          {counselor.is_online && (
            <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-green-500 border-2 border-white rounded-full"></div>
          )}
        </div>
        <div className="flex-1">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-lg font-semibold text-gray-800">
              {counselor.name}
            </h3>
            <div className="flex items-center">
              <i className="fas fa-star text-yellow-400 text-sm mr-1"></i>
              <span className="text-sm text-gray-600">{counselor.rating}</span>
            </div>
          </div>
          <p className="text-blue-600 text-sm font-medium mb-2">
            {counselor.specialization}
          </p>
          <p className="text-gray-600 text-sm mb-3 line-clamp-2">
            {counselor.bio}
          </p>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4 text-xs text-gray-500">
              <span
                className={`flex items-center ${
                  counselor.is_online ? "text-green-600" : "text-gray-500"
                }`}
              >
                <i
                  className={`fas fa-circle text-xs mr-1 ${
                    counselor.is_online ? "text-green-500" : "text-gray-400"
                  }`}
                ></i>
                {counselor.is_online ? "Online" : "Offline"}
              </span>
              {counselor.is_peer_mentor && (
                <span className="bg-purple-100 text-purple-800 px-2 py-1 rounded text-xs">
                  Peer Mentor
                </span>
              )}
            </div>
            <button
              onClick={() => startConversation(counselor)}
              disabled={loading}
              className="bg-blue-500 text-white px-4 py-2 rounded-lg text-sm hover:bg-blue-600 disabled:bg-gray-300 transition-colors"
            >
              {loading ? "Starting..." : "Start Chat"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  const renderConversationList = () => (
    <div className="h-full flex flex-col">
      <div className="p-4 border-b border-gray-200">
        <h2 className="text-lg font-semibold text-gray-800 mb-3">
          Conversations
        </h2>
        <button
          onClick={() => setCurrentView("browse")}
          className="w-full bg-blue-500 text-white py-2 px-4 rounded-lg hover:bg-blue-600 transition-colors"
        >
          <i className="fas fa-plus mr-2"></i>
          New Conversation
        </button>
      </div>
      <div className="flex-1 overflow-y-auto">
        {conversations.length === 0 ? (
          <div className="p-4 text-center text-gray-500">
            <i className="fas fa-comments text-3xl mb-3"></i>
            <p>No conversations yet</p>
            <p className="text-sm">Start chatting with a counselor</p>
          </div>
        ) : (
          conversations.map((conversation) => (
            <div
              key={conversation.id}
              onClick={() => {
                setSelectedConversation(conversation);
                loadMessages(conversation.id);
                setCurrentView("chat");
              }}
              className={`p-4 border-b border-gray-100 cursor-pointer hover:bg-gray-50 ${
                selectedConversation?.id === conversation.id
                  ? "bg-blue-50 border-blue-200"
                  : ""
              }`}
            >
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-gray-300 rounded-full flex items-center justify-center">
                  <i className="fas fa-user text-gray-600"></i>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <h3 className="text-sm font-semibold text-gray-800 truncate">
                      {conversation.counselorName}
                    </h3>
                    <span className="text-xs text-gray-500">
                      {formatTime(conversation.lastMessageTime)}
                    </span>
                  </div>
                  <p className="text-sm text-gray-600 truncate">
                    {conversation.lastMessage}
                  </p>
                </div>
                {conversation.unreadCount > 0 && (
                  <div className="w-5 h-5 bg-blue-500 text-white text-xs rounded-full flex items-center justify-center">
                    {conversation.unreadCount}
                  </div>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );

  const renderChatInterface = () => {
    if (!selectedConversation) {
      return (
        <div className="h-full flex items-center justify-center text-gray-500">
          <div className="text-center">
            <i className="fas fa-comments text-4xl mb-3"></i>
            <p>Select a conversation to start chatting</p>
          </div>
        </div>
      );
    }

    return (
      <div className="h-full flex flex-col">
        <div className="p-4 border-b border-gray-200 bg-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <button
                onClick={() => setCurrentView("conversations")}
                className="md:hidden text-gray-600 hover:text-gray-800"
              >
                <i className="fas fa-arrow-left"></i>
              </button>
              <div className="w-10 h-10 bg-gray-300 rounded-full flex items-center justify-center">
                <i className="fas fa-user text-gray-600"></i>
              </div>
              <div>
                <h3 className="font-semibold text-gray-800">
                  {selectedConversation.counselorName}
                </h3>
                <p className="text-sm text-green-600">Online</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <button
                onClick={() => setShowNotesModal(true)}
                className="p-2 text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-lg"
                title="Session Notes"
              >
                <i className="fas fa-sticky-note"></i>
              </button>
              <button
                onClick={() => setShowEmergencyModal(true)}
                className="p-2 text-red-600 hover:text-red-800 hover:bg-red-50 rounded-lg"
                title="Emergency Support"
              >
                <i className="fas fa-exclamation-triangle"></i>
              </button>
            </div>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${
                message.sender === "user" ? "justify-end" : "justify-start"
              }`}
            >
              <div
                className={`max-w-xs md:max-w-md px-4 py-3 rounded-2xl ${
                  message.sender === "user"
                    ? "bg-blue-500 text-white"
                    : "bg-white text-gray-800 shadow-sm"
                }`}
              >
                {message.fileUrl ? (
                  <div>
                    <div className="flex items-center space-x-2 mb-2">
                      <i className="fas fa-paperclip"></i>
                      <span className="text-sm">{message.fileName}</span>
                    </div>
                    {message.fileType?.startsWith("image/") ? (
                      <img
                        src={message.fileUrl}
                        alt={message.fileName}
                        className="max-w-full rounded"
                      />
                    ) : (
                      <a
                        href={message.fileUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-blue-300 hover:text-blue-100 underline"
                      >
                        Download File
                      </a>
                    )}
                  </div>
                ) : (
                  <p className="text-sm whitespace-pre-wrap">{message.text}</p>
                )}
                <div className="flex items-center justify-between mt-2">
                  <span
                    className={`text-xs ${
                      message.sender === "user"
                        ? "text-blue-100"
                        : "text-gray-500"
                    }`}
                  >
                    {formatTime(message.timestamp)}
                  </span>
                  {message.sender === "user" && (
                    <div className="flex items-center space-x-1">
                      {message.status === "sent" && (
                        <i className="fas fa-check text-xs text-blue-200"></i>
                      )}
                      {message.status === "delivered" && (
                        <i className="fas fa-check-double text-xs text-blue-200"></i>
                      )}
                      {message.status === "read" && (
                        <i className="fas fa-check-double text-xs text-blue-300"></i>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
          {isTyping && (
            <div className="flex justify-start">
              <div className="bg-white text-gray-800 px-4 py-3 rounded-2xl shadow-sm">
                <div className="flex items-center space-x-2">
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                    <div
                      className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                      style={{ animationDelay: "0.1s" }}
                    ></div>
                    <div
                      className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                      style={{ animationDelay: "0.2s" }}
                    ></div>
                  </div>
                  <span className="text-xs text-gray-500">Typing...</span>
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        <div className="p-4 bg-white border-t border-gray-200">
          <div className="flex items-end space-x-3">
            <div className="flex space-x-2">
              <button
                onClick={() => fileInputRef.current?.click()}
                disabled={uploadingFile}
                className="p-2 text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-lg"
                title="Attach File"
              >
                {uploadingFile ? (
                  <i className="fas fa-spinner fa-spin"></i>
                ) : (
                  <i className="fas fa-paperclip"></i>
                )}
              </button>
              <input
                ref={fileInputRef}
                type="file"
                onChange={handleFileUpload}
                className="hidden"
                accept="image/*,.pdf,.doc,.docx,.txt"
              />
            </div>
            <div className="flex-1">
              <textarea
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    sendMessage();
                  }
                }}
                placeholder="Type your message... (Press Enter to send)"
                className="w-full p-3 border border-gray-300 rounded-lg resize-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                rows="2"
              />
            </div>
            <button
              onClick={sendMessage}
              disabled={!newMessage.trim()}
              className="bg-blue-500 text-white p-3 rounded-lg hover:bg-blue-600 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
            >
              <i className="fas fa-paper-plane"></i>
            </button>
          </div>
        </div>
      </div>
    );
  };

  const renderBrowseCounselors = () => (
    <div className="h-full flex flex-col">
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-gray-800">
            Find a Counselor
          </h2>
          <button
            onClick={() => setCurrentView("conversations")}
            className="text-gray-600 hover:text-gray-800"
          >
            <i className="fas fa-times"></i>
          </button>
        </div>
        <div className="flex flex-col sm:flex-row gap-3">
          <input
            type="text"
            placeholder="Search counselors..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
          <select
            value={filterSpecialization}
            onChange={(e) => setFilterSpecialization(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="">All Specializations</option>
            {specializations.map((spec) => (
              <option key={spec} value={spec}>
                {spec}
              </option>
            ))}
          </select>
        </div>
      </div>
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {filteredCounselors.map(renderCounselorCard)}
        {filteredCounselors.length === 0 && (
          <div className="text-center text-gray-500 py-8">
            <i className="fas fa-search text-3xl mb-3"></i>
            <p>No counselors found matching your criteria</p>
          </div>
        )}
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <a
                href="/"
                className="flex items-center text-gray-600 hover:text-gray-900 mr-4"
              >
                <i className="fas fa-arrow-left mr-2"></i>
                Back to Dashboard
              </a>
            </div>
            <div className="flex items-center">
              <i className="fas fa-comments text-2xl text-blue-500 mr-3"></i>
              <h1 className="text-xl font-bold text-gray-900">
                Chat with Counselors
              </h1>
            </div>
            <div className="flex items-center">
              <span className="text-sm text-gray-600">
                {user.name || user.email}
              </span>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto h-[calc(100vh-4rem)]">
        <div className="flex h-full">
          {/* Mobile view */}
          <div className="md:hidden w-full">
            {currentView === "conversations" && renderConversationList()}
            {currentView === "chat" && renderChatInterface()}
            {currentView === "browse" && renderBrowseCounselors()}
          </div>

          {/* Desktop view */}
          <div className="hidden md:flex w-full">
            <div className="w-1/3 border-r border-gray-200 bg-white">
              {currentView === "browse"
                ? renderBrowseCounselors()
                : renderConversationList()}
            </div>
            <div className="flex-1 bg-gray-50">
              {currentView === "browse" ? (
                <div className="h-full flex items-center justify-center text-gray-500">
                  <div className="text-center">
                    <i className="fas fa-user-friends text-4xl mb-3"></i>
                    <p>Select a counselor to start a conversation</p>
                  </div>
                </div>
              ) : (
                renderChatInterface()
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Emergency Modal */}
      {showEmergencyModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-red-800">
                <i className="fas fa-exclamation-triangle mr-2"></i>
                Emergency Support
              </h3>
              <button
                onClick={() => setShowEmergencyModal(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                <i className="fas fa-times"></i>
              </button>
            </div>
            <div className="space-y-4">
              <p className="text-gray-700">
                If you're experiencing a mental health crisis or having thoughts
                of self-harm, please reach out for immediate help.
              </p>
              <div className="space-y-3">
                <a
                  href="tel:988"
                  className="block w-full bg-red-500 text-white py-3 px-4 rounded-lg text-center hover:bg-red-600 transition-colors"
                >
                  <i className="fas fa-phone mr-2"></i>
                  Crisis Lifeline: 988
                </a>
                <a
                  href="tel:911"
                  className="block w-full bg-orange-500 text-white py-3 px-4 rounded-lg text-center hover:bg-orange-600 transition-colors"
                >
                  <i className="fas fa-exclamation-triangle mr-2"></i>
                  Emergency: 911
                </a>
                <button
                  onClick={() => {
                    setShowEmergencyModal(false);
                    // In real app, this would escalate to emergency counselor
                    alert(
                      "Emergency escalation sent to available crisis counselors."
                    );
                  }}
                  className="block w-full bg-purple-500 text-white py-3 px-4 rounded-lg text-center hover:bg-purple-600 transition-colors"
                >
                  <i className="fas fa-user-md mr-2"></i>
                  Connect to Crisis Counselor
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Session Notes Modal */}
      {showNotesModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-800">
                <i className="fas fa-sticky-note mr-2"></i>
                Session Notes
              </h3>
              <button
                onClick={() => setShowNotesModal(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                <i className="fas fa-times"></i>
              </button>
            </div>
            <div className="space-y-4">
              <textarea
                value={sessionNotes}
                onChange={(e) => setSessionNotes(e.target.value)}
                placeholder="Add notes about this session..."
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                rows="6"
              />
              <div className="flex space-x-3">
                <button
                  onClick={() => {
                    setShowNotesModal(false);
                    // In real app, save notes to database
                    alert("Session notes saved successfully!");
                  }}
                  className="flex-1 bg-blue-500 text-white py-2 px-4 rounded-lg hover:bg-blue-600 transition-colors"
                >
                  Save Notes
                </button>
                <button
                  onClick={() => setShowNotesModal(false)}
                  className="flex-1 bg-gray-300 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-400 transition-colors"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {error && (
        <div className="fixed bottom-4 right-4 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg shadow-lg">
          {error}
          <button
            onClick={() => setError("")}
            className="ml-2 text-red-500 hover:text-red-700"
          >
            ×
          </button>
        </div>
      )}
    </div>
  );
}

export default MainComponent;