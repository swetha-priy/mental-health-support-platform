"use client";
import React from "react";

function MainComponent() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      <header className="bg-white/80 backdrop-blur-sm shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <i className="fas fa-heart text-2xl text-blue-500 mr-3"></i>
              <h1 className="text-xl font-bold text-gray-900">
                MindWell Support
              </h1>
            </div>
            <div className="flex items-center space-x-4">
              <a
                href="/account/signin"
                className="text-gray-600 hover:text-gray-900 px-3 py-2 text-sm font-medium"
              >
                Sign In
              </a>
              <a
                href="/account/signup"
                className="bg-blue-500 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-600 transition-colors"
              >
                Get Started
              </a>
            </div>
          </div>
        </div>
      </header>

      <section className="relative py-20 lg:py-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
              Your Journey to
              <span className="text-blue-500 block">Mental Wellness</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
              Take control of your mental health with personalized tools, guided
              meditation, professional resources, and 24/7 crisis support.
              You're not alone on this journey.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="/account/signup"
                className="bg-blue-500 text-white px-8 py-4 rounded-lg text-lg font-medium hover:bg-blue-600 transition-colors shadow-lg"
              >
                Start Your Journey
              </a>
              <a
                href="/"
                className="bg-white text-blue-500 px-8 py-4 rounded-lg text-lg font-medium hover:bg-gray-50 transition-colors border border-blue-200 shadow-lg"
              >
                View Dashboard
              </a>
            </div>
          </div>
        </div>
        <div className="absolute top-0 left-0 w-full h-full overflow-hidden -z-10">
          <div className="absolute top-20 left-10 w-20 h-20 bg-blue-200 rounded-full opacity-20"></div>
          <div className="absolute top-40 right-20 w-32 h-32 bg-indigo-200 rounded-full opacity-20"></div>
          <div className="absolute bottom-20 left-1/4 w-16 h-16 bg-purple-200 rounded-full opacity-20"></div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Everything You Need for Mental Wellness
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Comprehensive tools and resources designed to support your mental
              health journey every step of the way.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center p-6 rounded-2xl bg-blue-50 hover:bg-blue-100 transition-colors">
              <div className="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-smile text-2xl text-white"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                Mood Tracking
              </h3>
              <p className="text-gray-600">
                Monitor your emotional well-being with daily mood entries and
                track patterns over time.
              </p>
            </div>

            <div className="text-center p-6 rounded-2xl bg-indigo-50 hover:bg-indigo-100 transition-colors">
              <div className="w-16 h-16 bg-indigo-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-meditation text-2xl text-white"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                Guided Meditation
              </h3>
              <p className="text-gray-600">
                Access a library of meditation programs designed to reduce
                stress and improve mindfulness.
              </p>
            </div>

            <div className="text-center p-6 rounded-2xl bg-green-50 hover:bg-green-100 transition-colors">
              <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-book text-2xl text-white"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                Mental Health Resources
              </h3>
              <p className="text-gray-600">
                Explore articles, exercises, and tools curated by mental health
                professionals.
              </p>
            </div>

            <div className="text-center p-6 rounded-2xl bg-red-50 hover:bg-red-100 transition-colors">
              <div className="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-phone text-2xl text-white"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                Crisis Support
              </h3>
              <p className="text-gray-600">
                24/7 access to crisis hotlines and emergency mental health
                resources when you need them most.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-gradient-to-r from-blue-50 to-indigo-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                Take Control of Your Mental Health
              </h2>
              <div className="space-y-6">
                <div className="flex items-start">
                  <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center mr-4 mt-1">
                    <i className="fas fa-check text-white text-sm"></i>
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-1">
                      Track Your Progress
                    </h3>
                    <p className="text-gray-600">
                      Monitor mood patterns and meditation streaks to see your
                      growth over time.
                    </p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="w-8 h-8 bg-indigo-500 rounded-full flex items-center justify-center mr-4 mt-1">
                    <i className="fas fa-check text-white text-sm"></i>
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-1">
                      Professional Support
                    </h3>
                    <p className="text-gray-600">
                      Schedule appointments with counselors and access
                      professional resources.
                    </p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center mr-4 mt-1">
                    <i className="fas fa-check text-white text-sm"></i>
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-1">
                      Always Available
                    </h3>
                    <p className="text-gray-600">
                      Access your mental health tools anytime, anywhere, with
                      crisis support when needed.
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div className="bg-white p-8 rounded-2xl shadow-xl">
              <div className="text-center mb-6">
                <div className="w-20 h-20 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="fas fa-heart text-3xl text-white"></i>
                </div>
                <h3 className="text-2xl font-bold text-gray-900">
                  Start Today
                </h3>
                <p className="text-gray-600 mt-2">
                  Join thousands who have improved their mental wellness
                </p>
              </div>
              <div className="space-y-4">
                <a
                  href="/account/signup"
                  className="block w-full bg-blue-500 text-white py-3 px-6 rounded-lg text-center font-medium hover:bg-blue-600 transition-colors"
                >
                  Create Free Account
                </a>
                <a
                  href="/account/signin"
                  className="block w-full bg-gray-100 text-gray-700 py-3 px-6 rounded-lg text-center font-medium hover:bg-gray-200 transition-colors"
                >
                  Sign In to Continue
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Why Choose MindWell Support?
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Trusted by individuals seeking comprehensive mental health support
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-blue-50 p-8 rounded-2xl text-center">
              <div className="text-4xl font-bold text-blue-500 mb-2">
                10,000+
              </div>
              <div className="text-gray-600 font-medium">
                Meditation Minutes Completed
              </div>
              <p className="text-sm text-gray-500 mt-2">
                Users have found peace through our guided programs
              </p>
            </div>

            <div className="bg-indigo-50 p-8 rounded-2xl text-center">
              <div className="text-4xl font-bold text-indigo-500 mb-2">
                24/7
              </div>
              <div className="text-gray-600 font-medium">
                Crisis Support Available
              </div>
              <p className="text-sm text-gray-500 mt-2">
                Always here when you need help the most
              </p>
            </div>

            <div className="bg-green-50 p-8 rounded-2xl text-center">
              <div className="text-4xl font-bold text-green-500 mb-2">95%</div>
              <div className="text-gray-600 font-medium">
                User Satisfaction Rate
              </div>
              <p className="text-sm text-gray-500 mt-2">
                People love our comprehensive approach to wellness
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-gradient-to-r from-blue-500 to-indigo-600">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Ready to Start Your Mental Wellness Journey?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Join MindWell Support today and take the first step towards better
            mental health. Your well-being matters, and we're here to support
            you every step of the way.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="/account/signup"
              className="bg-white text-blue-600 px-8 py-4 rounded-lg text-lg font-medium hover:bg-gray-100 transition-colors shadow-lg"
            >
              Get Started Free
            </a>
            <a
              href="/"
              className="bg-transparent text-white px-8 py-4 rounded-lg text-lg font-medium hover:bg-white/10 transition-colors border border-white/30"
            >
              Explore Dashboard
            </a>
          </div>
        </div>
      </section>

      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center mb-4">
                <i className="fas fa-heart text-2xl text-blue-400 mr-3"></i>
                <h3 className="text-xl font-bold">MindWell Support</h3>
              </div>
              <p className="text-gray-400 mb-4 max-w-md">
                Your trusted companion for mental wellness. We provide
                comprehensive tools and resources to support your mental health
                journey with compassion and understanding.
              </p>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4">Features</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Mood Tracking</li>
                <li>Guided Meditation</li>
                <li>Crisis Support</li>
                <li>Professional Resources</li>
              </ul>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Crisis Hotline: 988</li>
                <li>Emergency: 911</li>
                <li>Help Center</li>
                <li>Contact Us</li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-8 pt-8 text-center">
            <p className="text-gray-400">
              © 2025 MindWell Support. Your mental health matters. You are not
              alone.
            </p>
            <p className="text-sm text-gray-500 mt-2">
              If you're experiencing a mental health crisis, please reach out
              for immediate help.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default MainComponent;