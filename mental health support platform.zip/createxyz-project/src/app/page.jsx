"use client";
import React from "react";

function MainComponent() {
  const [currentSection, setCurrentSection] = React.useState("dashboard");
  const { data: user, loading: userLoading } = useUser();
  const { signOut } = useAuth();
  const [moodEntries, setMoodEntries] = React.useState([]);
  const [resources, setResources] = React.useState([]);
  const [crisisContacts, setCrisisContacts] = React.useState([]);
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState("");

  const [currentMood, setCurrentMood] = React.useState(5);
  const [selectedEmotions, setSelectedEmotions] = React.useState([]);
  const [moodNotes, setMoodNotes] = React.useState("");

  const [appointmentForm, setAppointmentForm] = React.useState({
    counselor_name: "",
    appointment_date: "",
    session_type: "therapy",
    notes: "",
  });

  const [meditationPrograms, setMeditationPrograms] = React.useState([]);
  const [meditationSessions, setMeditationSessions] = React.useState([]);
  const [meditationStats, setMeditationStats] = React.useState({});
  const [activeMeditation, setActiveMeditation] = React.useState(null);
  const [meditationTimer, setMeditationTimer] = React.useState(0);
  const [isTimerRunning, setIsTimerRunning] = React.useState(false);
  const [moodBefore, setMoodBefore] = React.useState(5);
  const [moodAfter, setMoodAfter] = React.useState(5);
  const [meditationNotes, setMeditationNotes] = React.useState("");

  const emotions = [
    "Happy",
    "Sad",
    "Anxious",
    "Calm",
    "Angry",
    "Excited",
    "Tired",
    "Stressed",
    "Grateful",
    "Lonely",
  ];

  const loadData = React.useCallback(async () => {
    if (!user?.email) return;

    setLoading(true);
    try {
      const moodResponse = await fetch("/api/mood/list", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ user_email: user.email, limit: 10 }),
      });
      if (moodResponse.ok) {
        const moodData = await moodResponse.json();
        setMoodEntries(Array.isArray(moodData) ? moodData : []);
      }

      const resourcesResponse = await fetch("/api/resources/list", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });
      if (resourcesResponse.ok) {
        const resourcesData = await resourcesResponse.json();
        setResources(Array.isArray(resourcesData) ? resourcesData : []);
      }

      const crisisResponse = await fetch("/api/crisis/list", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });
      if (crisisResponse.ok) {
        const crisisData = await crisisResponse.json();
        setCrisisContacts(Array.isArray(crisisData) ? crisisData : []);
      }

      const programsResponse = await fetch("/api/meditation/programs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });
      if (programsResponse.ok) {
        const programsData = await programsResponse.json();
        setMeditationPrograms(Array.isArray(programsData) ? programsData : []);
      }

      const sessionsResponse = await fetch("/api/meditation/list", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ user_email: user.email, limit: 10 }),
      });
      if (sessionsResponse.ok) {
        const sessionsData = await sessionsResponse.json();
        setMeditationSessions(
          Array.isArray(sessionsData.sessions) ? sessionsData.sessions : []
        );
        setMeditationStats(sessionsData.stats || {});
      }
    } catch (err) {
      console.error("Error loading data:", err);
      setError("Failed to load data");
    }
    setLoading(false);
  }, [user?.email]);

  React.useEffect(() => {
    if (user) {
      loadData();
    }
  }, [user, loadData]);

  React.useEffect(() => {
    let interval;
    if (isTimerRunning && activeMeditation) {
      interval = setInterval(() => {
        setMeditationTimer((prev) => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isTimerRunning, activeMeditation]);

  if (userLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <i className="fas fa-heart text-4xl text-blue-500 mb-4"></i>
          <p className="text-gray-600">
            Loading your mental health dashboard...
          </p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-white rounded-2xl p-8 shadow-xl text-center">
          <i className="fas fa-heart text-4xl text-blue-500 mb-4"></i>
          <h1 className="text-2xl font-bold text-gray-800 mb-4">
            Welcome to MindWell Support
          </h1>
          <p className="text-gray-600 mb-6">
            Your personal mental health companion. Please sign in to access your
            dashboard.
          </p>
          <div className="space-y-3">
            <a
              href="/account/signin"
              className="block w-full bg-blue-500 text-white py-3 px-4 rounded-lg hover:bg-blue-600 transition-colors"
            >
              Sign In
            </a>
            <a
              href="/account/signup"
              className="block w-full bg-gray-100 text-gray-700 py-3 px-4 rounded-lg hover:bg-gray-200 transition-colors"
            >
              Create Account
            </a>
          </div>
        </div>
      </div>
    );
  }

  const saveMoodEntry = async () => {
    if (!currentMood) return;
    setLoading(true);
    try {
      const response = await fetch("/api/mood/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          user_email: user.email,
          mood_score: currentMood,
          emotions: selectedEmotions,
          notes: moodNotes,
        }),
      });

      if (response.ok) {
        setCurrentMood(5);
        setSelectedEmotions([]);
        setMoodNotes("");
        loadData();
      } else {
        setError("Failed to save mood entry");
      }
    } catch (err) {
      console.error("Error saving mood:", err);
      setError("Failed to save mood entry");
    }
    setLoading(false);
  };

  const scheduleAppointment = async () => {
    if (!appointmentForm.counselor_name || !appointmentForm.appointment_date) {
      setError("Please fill in required fields");
      return;
    }

    setLoading(true);
    try {
      const response = await fetch("/api/appointments/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          user_email: user.email,
          ...appointmentForm,
        }),
      });

      if (response.ok) {
        setAppointmentForm({
          counselor_name: "",
          appointment_date: "",
          session_type: "therapy",
          notes: "",
        });
        setError("");
        alert("Appointment scheduled successfully!");
      } else {
        setError("Failed to schedule appointment");
      }
    } catch (err) {
      console.error("Error scheduling appointment:", err);
      setError("Failed to schedule appointment");
    }
    setLoading(false);
  };

  const startMeditation = (program) => {
    setActiveMeditation(program);
    setMeditationTimer(0);
    setIsTimerRunning(true);
    setCurrentSection("meditation-active");
  };

  const pauseMeditation = () => {
    setIsTimerRunning(false);
  };

  const resumeMeditation = () => {
    setIsTimerRunning(true);
  };

  const completeMeditation = () => {
    setIsTimerRunning(false);
    setCurrentSection("meditation-complete");
  };

  const saveMeditationSession = async () => {
    if (!activeMeditation) return;

    setLoading(true);
    try {
      const response = await fetch("/api/meditation/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          user_email: user.email,
          session_type: activeMeditation.session_type,
          duration_minutes: Math.floor(meditationTimer / 60),
          planned_duration: activeMeditation.duration_minutes,
          meditation_title: activeMeditation.title,
          notes: meditationNotes,
          mood_before: moodBefore,
          mood_after: moodAfter,
        }),
      });

      if (response.ok) {
        setActiveMeditation(null);
        setMeditationTimer(0);
        setMoodBefore(5);
        setMoodAfter(5);
        setMeditationNotes("");
        setCurrentSection("meditation");
        loadData();
      } else {
        setError("Failed to save meditation session");
      }
    } catch (err) {
      console.error("Error saving meditation session:", err);
      setError("Failed to save meditation session");
    }
    setLoading(false);
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs
      .toString()
      .padStart(2, "0")}`;
  };

  const handleSignOut = async () => {
    await signOut({
      callbackUrl: "/",
      redirect: true,
    });
  };

  const toggleEmotion = (emotion) => {
    setSelectedEmotions((prev) =>
      prev.includes(emotion)
        ? prev.filter((e) => e !== emotion)
        : [...prev, emotion]
    );
  };

  const getMoodColor = (score) => {
    if (score <= 3) return "text-red-500";
    if (score <= 6) return "text-yellow-500";
    return "text-green-500";
  };

  const getAverageMood = () => {
    if (moodEntries.length === 0) return 0;
    const sum = moodEntries.reduce((acc, entry) => acc + entry.mood_score, 0);
    return (sum / moodEntries.length).toFixed(1);
  };

  const renderDashboard = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-blue-50 p-6 rounded-lg">
          <h3 className="text-lg font-semibold text-gray-800 mb-2">
            Average Mood
          </h3>
          <p className={`text-3xl font-bold ${getMoodColor(getAverageMood())}`}>
            {getAverageMood()}/10
          </p>
          <p className="text-sm text-gray-600 mt-1">Last 10 entries</p>
        </div>

        <div className="bg-green-50 p-6 rounded-lg">
          <h3 className="text-lg font-semibold text-gray-800 mb-2">
            Meditation Minutes
          </h3>
          <p className="text-3xl font-bold text-green-600">
            {meditationStats.total_minutes || 0}
          </p>
          <p className="text-sm text-gray-600 mt-1">Total practiced</p>
        </div>

        <div className="bg-purple-50 p-6 rounded-lg">
          <h3 className="text-lg font-semibold text-gray-800 mb-2">
            Meditation Streak
          </h3>
          <p className="text-3xl font-bold text-purple-600">
            {meditationStats.current_streak || 0}
          </p>
          <p className="text-sm text-gray-600 mt-1">Days in a row</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">
            Recent Mood Entries
          </h3>
          {moodEntries.slice(0, 5).map((entry) => (
            <div
              key={entry.id}
              className="flex justify-between items-center py-2 border-b border-gray-100 last:border-b-0"
            >
              <span className="text-sm text-gray-600">
                {new Date(entry.created_at).toLocaleDateString()}
              </span>
              <span
                className={`font-semibold ${getMoodColor(entry.mood_score)}`}
              >
                {entry.mood_score}/10
              </span>
            </div>
          ))}
          {moodEntries.length === 0 && (
            <p className="text-gray-500 text-center py-4">
              No mood entries yet
            </p>
          )}
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">
            Quick Actions
          </h3>
          <div className="space-y-3">
            <button
              onClick={() => setCurrentSection("mood")}
              className="w-full bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600 transition-colors"
            >
              Track Your Mood
            </button>
            <button
              onClick={() => setCurrentSection("meditation")}
              className="w-full bg-indigo-500 text-white py-2 px-4 rounded hover:bg-indigo-600 transition-colors"
            >
              Start Meditation
            </button>
            <button
              onClick={() => setCurrentSection("resources")}
              className="w-full bg-green-500 text-white py-2 px-4 rounded hover:bg-green-600 transition-colors"
            >
              Browse Resources
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  const renderMoodTracking = () => (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="bg-white p-6 rounded-lg shadow">
        <h3 className="text-xl font-semibold text-gray-800 mb-4">
          How are you feeling today?
        </h3>

        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Mood Score (1 = Very Low, 10 = Excellent)
          </label>
          <input
            type="range"
            min="1"
            max="10"
            value={currentMood}
            onChange={(e) => setCurrentMood(parseInt(e.target.value))}
            className="w-full"
          />
          <div className="flex justify-between text-sm text-gray-500 mt-1">
            <span>1</span>
            <span className={`font-bold ${getMoodColor(currentMood)}`}>
              {currentMood}
            </span>
            <span>10</span>
          </div>
        </div>

        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            What emotions are you experiencing?
          </label>
          <div className="flex flex-wrap gap-2">
            {emotions.map((emotion) => (
              <button
                key={emotion}
                onClick={() => toggleEmotion(emotion)}
                className={`px-3 py-1 rounded-full text-sm transition-colors ${
                  selectedEmotions.includes(emotion)
                    ? "bg-blue-500 text-white"
                    : "bg-gray-200 text-gray-700 hover:bg-gray-300"
                }`}
              >
                {emotion}
              </button>
            ))}
          </div>
        </div>

        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Notes (optional)
          </label>
          <textarea
            value={moodNotes}
            onChange={(e) => setMoodNotes(e.target.value)}
            className="w-full p-3 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            rows="3"
            placeholder="What's on your mind?"
          />
        </div>

        <button
          onClick={saveMoodEntry}
          disabled={loading}
          className="w-full bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600 disabled:bg-gray-300 transition-colors"
        >
          {loading ? "Saving..." : "Save Mood Entry"}
        </button>
      </div>

      <div className="bg-white p-6 rounded-lg shadow">
        <h3 className="text-xl font-semibold text-gray-800 mb-4">
          Your Mood History
        </h3>
        {moodEntries.map((entry) => (
          <div
            key={entry.id}
            className="border-b border-gray-100 py-3 last:border-b-0"
          >
            <div className="flex justify-between items-start">
              <div>
                <span
                  className={`text-lg font-semibold ${getMoodColor(
                    entry.mood_score
                  )}`}
                >
                  {entry.mood_score}/10
                </span>
                <p className="text-sm text-gray-600">
                  {new Date(entry.created_at).toLocaleDateString()} at{" "}
                  {new Date(entry.created_at).toLocaleTimeString()}
                </p>
                {entry.emotions && entry.emotions.length > 0 && (
                  <p className="text-sm text-gray-700 mt-1">
                    Emotions: {entry.emotions.join(", ")}
                  </p>
                )}
                {entry.notes && (
                  <p className="text-sm text-gray-700 mt-1 italic">
                    "{entry.notes}"
                  </p>
                )}
              </div>
            </div>
          </div>
        ))}
        {moodEntries.length === 0 && (
          <p className="text-gray-500 text-center py-4">
            No mood entries yet. Start tracking today!
          </p>
        )}
      </div>
    </div>
  );

  const renderMeditation = () => (
    <div className="space-y-6">
      <div className="text-center">
        <h3 className="text-xl font-semibold text-gray-800 mb-2">
          Meditation Programs
        </h3>
        <p className="text-gray-600">
          Choose a meditation program to help you relax and find inner peace
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {meditationPrograms.map((program) => (
          <div
            key={program.id}
            className="bg-white p-6 rounded-lg shadow hover:shadow-lg transition-shadow"
          >
            <div className="mb-4">
              <span className="inline-block bg-indigo-100 text-indigo-800 text-xs px-2 py-1 rounded">
                {program.category}
              </span>
              <span className="inline-block bg-gray-100 text-gray-800 text-xs px-2 py-1 rounded ml-2">
                {program.duration_minutes} min
              </span>
            </div>
            <h4 className="text-lg font-semibold text-gray-800 mb-2">
              {program.title}
            </h4>
            <p className="text-gray-600 text-sm mb-4">{program.description}</p>
            <button
              onClick={() => startMeditation(program)}
              className="w-full bg-indigo-500 text-white py-2 px-4 rounded hover:bg-indigo-600 transition-colors"
            >
              Start Meditation
            </button>
          </div>
        ))}
      </div>

      {meditationPrograms.length === 0 && (
        <div className="text-center py-8">
          <p className="text-gray-500">
            No meditation programs available at the moment.
          </p>
        </div>
      )}

      <div className="bg-white p-6 rounded-lg shadow">
        <h3 className="text-xl font-semibold text-gray-800 mb-4">
          Your Meditation History
        </h3>
        {meditationSessions.map((session) => (
          <div
            key={session.id}
            className="border-b border-gray-100 py-3 last:border-b-0"
          >
            <div className="flex justify-between items-start">
              <div>
                <h4 className="font-semibold text-gray-800">
                  {session.meditation_title || session.session_type}
                </h4>
                <p className="text-sm text-gray-600">
                  {new Date(session.completed_at).toLocaleDateString()} -{" "}
                  {session.duration_minutes} minutes
                </p>
                {session.notes && (
                  <p className="text-sm text-gray-700 mt-1 italic">
                    "{session.notes}"
                  </p>
                )}
              </div>
              <div className="text-right">
                {session.mood_before && (
                  <p className="text-xs text-gray-500">
                    Before: {session.mood_before}/10
                  </p>
                )}
                {session.mood_after && (
                  <p className="text-xs text-gray-500">
                    After: {session.mood_after}/10
                  </p>
                )}
              </div>
            </div>
          </div>
        ))}
        {meditationSessions.length === 0 && (
          <p className="text-gray-500 text-center py-4">
            No meditation sessions yet. Start your first session today!
          </p>
        )}
      </div>
    </div>
  );

  const renderMeditationActive = () => (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="bg-white p-8 rounded-lg shadow text-center">
        <h3 className="text-2xl font-semibold text-gray-800 mb-4">
          {activeMeditation?.title}
        </h3>

        <div className="mb-8">
          <div className="text-6xl font-bold text-indigo-600 mb-2">
            {formatTime(meditationTimer)}
          </div>
          <p className="text-gray-600">
            Target: {activeMeditation?.duration_minutes} minutes
          </p>
        </div>

        <div className="mb-6">
          <p className="text-gray-700 mb-4">{activeMeditation?.instructions}</p>
        </div>

        <div className="flex justify-center space-x-4">
          {isTimerRunning ? (
            <button
              onClick={pauseMeditation}
              className="bg-yellow-500 text-white px-6 py-3 rounded-lg hover:bg-yellow-600 transition-colors"
            >
              <i className="fas fa-pause mr-2"></i>
              Pause
            </button>
          ) : (
            <button
              onClick={resumeMeditation}
              className="bg-green-500 text-white px-6 py-3 rounded-lg hover:bg-green-600 transition-colors"
            >
              <i className="fas fa-play mr-2"></i>
              Resume
            </button>
          )}

          <button
            onClick={completeMeditation}
            className="bg-indigo-500 text-white px-6 py-3 rounded-lg hover:bg-indigo-600 transition-colors"
          >
            <i className="fas fa-check mr-2"></i>
            Complete
          </button>
        </div>
      </div>
    </div>
  );

  const renderMeditationComplete = () => (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="bg-white p-6 rounded-lg shadow">
        <h3 className="text-xl font-semibold text-gray-800 mb-4">
          Meditation Complete! 🧘‍♀️
        </h3>

        <div className="mb-6 text-center">
          <p className="text-lg text-gray-700 mb-2">
            You meditated for {Math.floor(meditationTimer / 60)} minutes
          </p>
          <p className="text-gray-600">
            Great job on completing "{activeMeditation?.title}"
          </p>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              How did you feel before? (1-10)
            </label>
            <input
              type="range"
              min="1"
              max="10"
              value={moodBefore}
              onChange={(e) => setMoodBefore(parseInt(e.target.value))}
              className="w-full"
            />
            <div className="flex justify-between text-sm text-gray-500 mt-1">
              <span>1</span>
              <span className={`font-bold ${getMoodColor(moodBefore)}`}>
                {moodBefore}
              </span>
              <span>10</span>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              How do you feel now? (1-10)
            </label>
            <input
              type="range"
              min="1"
              max="10"
              value={moodAfter}
              onChange={(e) => setMoodAfter(parseInt(e.target.value))}
              className="w-full"
            />
            <div className="flex justify-between text-sm text-gray-500 mt-1">
              <span>1</span>
              <span className={`font-bold ${getMoodColor(moodAfter)}`}>
                {moodAfter}
              </span>
              <span>10</span>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Notes (optional)
            </label>
            <textarea
              value={meditationNotes}
              onChange={(e) => setMeditationNotes(e.target.value)}
              className="w-full p-3 border border-gray-300 rounded focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              rows="3"
              placeholder="How was your meditation experience?"
            />
          </div>

          <button
            onClick={saveMeditationSession}
            disabled={loading}
            className="w-full bg-indigo-500 text-white py-2 px-4 rounded hover:bg-indigo-600 disabled:bg-gray-300 transition-colors"
          >
            {loading ? "Saving..." : "Save Session"}
          </button>
        </div>
      </div>
    </div>
  );

  const renderResources = () => (
    <div className="space-y-6">
      <div className="text-center">
        <h3 className="text-xl font-semibold text-gray-800 mb-2">
          Mental Health Resources
        </h3>
        <p className="text-gray-600">
          Explore helpful articles, exercises, and tools for your mental
          wellness
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {resources.map((resource) => (
          <div
            key={resource.id}
            className="bg-white p-6 rounded-lg shadow hover:shadow-lg transition-shadow"
          >
            <div className="mb-4">
              <span className="inline-block bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded">
                {resource.category}
              </span>
              <span className="inline-block bg-gray-100 text-gray-800 text-xs px-2 py-1 rounded ml-2">
                {resource.resource_type}
              </span>
            </div>
            <h4 className="text-lg font-semibold text-gray-800 mb-2">
              {resource.title}
            </h4>
            <p className="text-gray-600 text-sm mb-4 line-clamp-3">
              {resource.content}
            </p>
            {resource.external_url && (
              <a
                href={resource.external_url}
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-500 hover:text-blue-600 text-sm"
              >
                Learn More →
              </a>
            )}
          </div>
        ))}
      </div>

      {resources.length === 0 && (
        <div className="text-center py-8">
          <p className="text-gray-500">No resources available at the moment.</p>
        </div>
      )}
    </div>
  );

  const renderAppointments = () => (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="bg-white p-6 rounded-lg shadow">
        <h3 className="text-xl font-semibold text-gray-800 mb-4">
          Schedule an Appointment
        </h3>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Counselor Name *
            </label>
            <input
              type="text"
              value={appointmentForm.counselor_name}
              onChange={(e) =>
                setAppointmentForm((prev) => ({
                  ...prev,
                  counselor_name: e.target.value,
                }))
              }
              className="w-full p-3 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Enter counselor name"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Appointment Date & Time *
            </label>
            <input
              type="datetime-local"
              value={appointmentForm.appointment_date}
              onChange={(e) =>
                setAppointmentForm((prev) => ({
                  ...prev,
                  appointment_date: e.target.value,
                }))
              }
              className="w-full p-3 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Session Type
            </label>
            <select
              value={appointmentForm.session_type}
              onChange={(e) =>
                setAppointmentForm((prev) => ({
                  ...prev,
                  session_type: e.target.value,
                }))
              }
              className="w-full p-3 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="therapy">Individual Therapy</option>
              <option value="group">Group Therapy</option>
              <option value="consultation">Consultation</option>
              <option value="follow-up">Follow-up</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Notes (optional)
            </label>
            <textarea
              value={appointmentForm.notes}
              onChange={(e) =>
                setAppointmentForm((prev) => ({
                  ...prev,
                  notes: e.target.value,
                }))
              }
              className="w-full p-3 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              rows="3"
              placeholder="Any specific topics or concerns you'd like to discuss?"
            />
          </div>

          <button
            onClick={scheduleAppointment}
            disabled={loading}
            className="w-full bg-purple-500 text-white py-2 px-4 rounded hover:bg-purple-600 disabled:bg-gray-300 transition-colors"
          >
            {loading ? "Scheduling..." : "Schedule Appointment"}
          </button>
        </div>
      </div>
    </div>
  );

  const renderCrisis = () => (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="bg-red-50 border border-red-200 p-6 rounded-lg">
        <h3 className="text-xl font-semibold text-red-800 mb-2">
          <i className="fas fa-exclamation-triangle mr-2"></i>
          Crisis Support
        </h3>
        <p className="text-red-700">
          If you're experiencing a mental health crisis or having thoughts of
          self-harm, please reach out for immediate help. You are not alone.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {crisisContacts.map((contact) => (
          <div
            key={contact.id}
            className="bg-white p-6 rounded-lg shadow border-l-4 border-red-500"
          >
            <h4 className="text-lg font-semibold text-gray-800 mb-2">
              {contact.name}
            </h4>
            <div className="space-y-2">
              <p className="text-xl font-bold text-blue-600">
                <i className="fas fa-phone mr-2"></i>
                {contact.phone}
              </p>
              <p className="text-gray-600">{contact.description}</p>
              <p className="text-sm text-gray-500">
                <i className="fas fa-clock mr-1"></i>
                Available: {contact.availability}
              </p>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-blue-50 p-6 rounded-lg">
        <h4 className="text-lg font-semibold text-blue-800 mb-3">
          Additional Resources
        </h4>
        <ul className="space-y-2 text-blue-700">
          <li>
            • If this is a life-threatening emergency, call 911 immediately
          </li>
          <li>• Consider going to your nearest emergency room</li>
          <li>
            • Reach out to a trusted friend, family member, or mental health
            professional
          </li>
          <li>• Use safety apps like "MY3" to create a support network</li>
        </ul>
      </div>
    </div>
  );

  const navigationItems = [
    { id: "dashboard", label: "Dashboard", icon: "fas fa-tachometer-alt" },
    { id: "mood", label: "Mood Tracking", icon: "fas fa-smile" },
    { id: "meditation", label: "Meditation", icon: "fas fa-meditation" },
    { id: "resources", label: "Resources", icon: "fas fa-book" },
    { id: "appointments", label: "Appointments", icon: "fas fa-calendar" },
    {
      id: "crisis",
      label: "Crisis Support",
      icon: "fas fa-exclamation-triangle",
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <i className="fas fa-heart text-2xl text-blue-500 mr-3"></i>
              <h1 className="text-xl font-bold text-gray-900">
                MindWell Support
              </h1>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">
                Welcome back, {user.name || user.email}!
              </span>
              <button
                onClick={handleSignOut}
                className="text-sm text-gray-500 hover:text-gray-700 flex items-center"
              >
                <i className="fas fa-sign-out-alt mr-1"></i>
                Sign Out
              </button>
            </div>
          </div>
        </div>
      </header>

      <nav className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex space-x-8 overflow-x-auto">
            {navigationItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setCurrentSection(item.id)}
                className={`flex items-center px-3 py-4 text-sm font-medium border-b-2 transition-colors ${
                  currentSection === item.id
                    ? "border-blue-500 text-blue-600"
                    : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                }`}
              >
                <i className={`${item.icon} mr-2`}></i>
                {item.label}
              </button>
            ))}
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-4">
            {error}
            <button
              onClick={() => setError("")}
              className="float-right text-red-500 hover:text-red-700"
            >
              ×
            </button>
          </div>
        )}

        {currentSection === "dashboard" && renderDashboard()}
        {currentSection === "mood" && renderMoodTracking()}
        {currentSection === "meditation" && renderMeditation()}
        {currentSection === "meditation-active" && renderMeditationActive()}
        {currentSection === "meditation-complete" && renderMeditationComplete()}
        {currentSection === "resources" && renderResources()}
        {currentSection === "appointments" && renderAppointments()}
        {currentSection === "crisis" && renderCrisis()}
      </main>

      <footer className="bg-white border-t mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="text-center text-gray-600 text-sm">
            <p>
              Remember: This platform is for support and information. In case of
              emergency, please contact emergency services.
            </p>
            <p className="mt-2">
              Your mental health matters. You are not alone.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default MainComponent;